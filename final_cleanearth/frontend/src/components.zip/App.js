import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import RequestPage from './pages/RequestPage';
import VolunteerDashboard from './pages/VolunteerDashboard';
import CampRegister from './pages/CampRegister';
import VolunteerLeaderboard from './pages/VolunteerLeaderboard';
import AboutUs from './pages/AboutUs';
import AdminDashboard from './pages/AdminDashboard';

function App() {
  return (
    <div className="w-screen overflow-x-hidden">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/report" element={<RequestPage />} />
          <Route path="/volunteer" element={<VolunteerDashboard />} />
          <Route path="/camps" element={<VolunteerDashboard />} />
          <Route path="/camp-register" element={<CampRegister />} />
          <Route path="/leaderboard" element={<VolunteerLeaderboard />} />
          <Route path="/logs" element={<HomePage />} /> {/* Replace with LogsPage when created */}
          <Route path="/badges" element={<HomePage />} /> {/* Replace with BadgesPage when created */}
          <Route path="/about" element={<AboutUs />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="*" element={<HomePage />} /> {/* Fallback for any unknown routes */}
        </Routes>
    </div>
  );
}

export default App;