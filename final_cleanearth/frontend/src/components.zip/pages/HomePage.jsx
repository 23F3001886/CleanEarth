import React from "react";
import Navbar from "../components/Navbar";
import { FaFilter, FaMapMarkerAlt, FaTree, FaWater, FaHandHoldingWater } from "react-icons/fa";
import { MdLocationPin, MdOutlineCleaningServices } from "react-icons/md";
import { BsPatchCheckFill, BsGlobe2 } from "react-icons/bs";
import { GiLaurelsTrophy, GiEarthAmerica } from "react-icons/gi";
import "../styles/custom.css";

const HomePage = () => (
  <div className="flex min-h-screen w-full">
    {/* Sidebar Navbar */}
    <Navbar active="Home" />
    
    {/* Main Content */}
    <main className="eco-main flex-1">
      {/* Header Section with Earth-saving message */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-eco-green-dark mb-2">Welcome to CleanEarth</h1>
        <p className="text-gray-600">Join our mission to preserve and protect our planet. Every small action counts!</p>
        
        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-4 mt-6">
          <div className="stat-card">
            <div className="stat-icon stat-green">
              <FaTree />
            </div>
            <div className="stat-content">
              <h4>Trees Planted</h4>
              <div className="stat-value">1,243</div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon stat-blue">
              <FaWater />
            </div>
            <div className="stat-content">
              <h4>Water Cleaned</h4>
              <div className="stat-value">532 L</div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon stat-green">
              <MdOutlineCleaningServices />
            </div>
            <div className="stat-content">
              <h4>Cleanups</h4>
              <div className="stat-value">89</div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon stat-blue">
              <BsGlobe2 />
            </div>
            <div className="stat-content">
              <h4>CO₂ Reduced</h4>
              <div className="stat-value">2.4 T</div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Cards Section */}
      <h2 className="section-header mb-6 text-xl">Take Action Now</h2>
      <div className="dashboard-grid mb-10">
        {/* Report Location */}
        <div className="action-card">
          <MdLocationPin className="action-card-icon" />
          <h3>Report Location</h3>
          <p className="mb-4">Spot pollution or waste? Report it and help keep your community clean.</p>
          <button className="eco-btn eco-btn-primary">Report Now</button>
        </div>

        {/* Completed Logs */}
        <div className="action-card">
          <BsPatchCheckFill className="action-card-icon" />
          <h3>Completed Logs</h3>
          <p className="mb-4">View all the locations that have been successfully cleaned.</p>
          <button className="eco-btn eco-btn-primary">View Logs</button>
        </div>

        {/* Your Badges */}
        <div className="action-card">
          <GiLaurelsTrophy className="action-card-icon" />
          <h3>Your Badges</h3>
          <p className="mb-4">Check your earned badges and eco-achievements. Earn more!</p>
          <button className="eco-btn eco-btn-primary">See Badges</button>
        </div>
      </div>

      {/* Activity Sections */}
      <div className="grid grid-cols-2 gap-8">
        {/* Nearby Activity */}
        <div className="eco-card">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center">
              <FaMapMarkerAlt className="text-eco-green mr-2 text-xl" />
              <h3 className="font-semibold text-xl text-eco-green-dark">Nearby Activity</h3>
            </div>
            <button className="eco-btn eco-btn-secondary text-sm">View All</button>
          </div>
          
          <ul className="space-y-4">
            <li className="flex items-center justify-between border-b pb-3">
              <div className="flex items-start">
                <FaHandHoldingWater className="text-eco-green-dark mt-1 mr-3" />
                <div>
                  <h4 className="font-medium">Plastic waste at Beach Shore</h4>
                  <p className="text-sm text-gray-600">Reported 2 hours ago • 1.2 km away</p>
                </div>
              </div>
              <span className="status-badge status-pending">Pending</span>
            </li>
            
            <li className="flex items-center justify-between border-b pb-3">
              <div className="flex items-start">
                <GiEarthAmerica className="text-eco-green-dark mt-1 mr-3" />
                <div>
                  <h4 className="font-medium">Community Garden Cleanup</h4>
                  <p className="text-sm text-gray-600">Completed yesterday • 0.5 km away</p>
                </div>
              </div>
              <span className="status-badge status-completed">Completed</span>
            </li>
            
            <li className="flex items-center justify-between">
              <div className="flex items-start">
                <FaTree className="text-eco-green-dark mt-1 mr-3" />
                <div>
                  <h4 className="font-medium">Tree Planting Event</h4>
                  <p className="text-sm text-gray-600">Scheduled for tomorrow • 2.0 km away</p>
                </div>
              </div>
              <span className="status-badge status-pending">Upcoming</span>
            </li>
          </ul>
        </div>

        {/* Filtered by Pincode */}
        <div className="eco-card">
          <div className="flex items-center mb-5">
            <FaFilter className="text-eco-green mr-2 text-xl" />
            <h3 className="font-semibold text-xl text-eco-green-dark">Find by Location</h3>
          </div>
          
          <div className="eco-input-group mb-5">
            <input
              type="text"
              placeholder="Enter Pincode or Area"
              className="eco-input"
            />
            <button className="eco-btn eco-btn-primary">Search</button>
          </div>
          
          <div className="bg-eco-green-light bg-opacity-20 rounded-lg p-4 mb-4">
            <h4 className="font-medium mb-2">Popular Areas</h4>
            <div className="flex flex-wrap gap-2">
              <button className="bg-white rounded-full px-3 py-1 text-sm border border-eco-green text-eco-green-dark hover:bg-eco-green-light transition">Central Park</button>
              <button className="bg-white rounded-full px-3 py-1 text-sm border border-eco-green text-eco-green-dark hover:bg-eco-green-light transition">Beach Front</button>
              <button className="bg-white rounded-full px-3 py-1 text-sm border border-eco-green text-eco-green-dark hover:bg-eco-green-light transition">City Center</button>
            </div>
          </div>
          
          <ul className="space-y-3">
            <li className="flex justify-between items-center">
              <span className="font-medium">110001</span>
              <span className="text-eco-green-dark">3 active reports</span>
            </li>
            <li className="flex justify-between items-center">
              <span className="font-medium">110002</span>
              <span className="text-eco-green-dark">1 cleanup drive</span>
            </li>
            <li className="flex justify-between items-center">
              <span className="font-medium">110003</span>
              <span className="text-eco-green-dark">2 completed cleanups</span>
            </li>
          </ul>
        </div>
      </div>
      
      {/* Call to Action */}
      <div className="mt-10 text-center">
        <h3 className="text-xl font-bold mb-2 text-eco-green-dark">Ready to make a difference?</h3>
        <p className="mb-4">Join thousands of volunteers around the world committed to saving our planet</p>
        <button className="eco-btn eco-btn-primary px-8 py-3">Start Your Journey</button>
      </div>
    </main>
  </div>
);

export default HomePage;