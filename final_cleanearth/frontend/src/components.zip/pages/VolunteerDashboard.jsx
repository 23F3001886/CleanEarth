import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import VolunteerNavbar from "../components/VolunteerNavbar";
import { 
  FaMapMarkerAlt, 
  FaCheck, 
  FaTimes, 
  FaPlus,
  FaTrash,
  FaCalendarAlt,
  FaMedal,
  FaUsers
} from "react-icons/fa";

const VolunteerDashboard = () => {
  // State handling different data
  const [requestsData, setRequestsData] = useState([]);
  const [upcomingCamps, setUpcomingCamps] = useState([]);
  const [completedCamps, setCompletedCamps] = useState([]);
  const [badges, setBadges] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateCampModal, setShowCreateCampModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);

  // Data on component mount
  useEffect(() => {
    // Mock data for demonstration
    const mockRequests = [
      {
        id: 1,
        location: "Green Park, Sector 15",
        description: "Large plastic waste accumulation",
        date: "2025-05-10",
        imageUrl: "https://example.com/image1.jpg",
        pincode: "110049"
      },
      {
        id: 2,
        location: "River Bank, Downtown",
        description: "Illegal dumping near water body",
        date: "2025-05-13",
        imageUrl: "https://example.com/image2.jpg",
        pincode: "110001"
      },
      {
        id: 3,
        location: "Community Garden",
        description: "Construction debris needs removal",
        date: "2025-05-14",
        imageUrl: "https://example.com/image3.jpg",
        pincode: "110005"
      }
    ];
    
    const mockUpcomingCamps = [
      {
        id: 101,
        name: "River Cleanup Drive",
        location: "Main River, North Bank",
        date: "2025-05-18",
        participants: 8,
        status: "confirmed"
      },
      {
        id: 102,
        name: "Park Beautification",
        location: "Central Park",
        date: "2025-05-25",
        participants: 15,
        status: "pending"
      }
    ];
    
    const mockCompletedCamps = [
      {
        id: 201,
        name: "Beach Cleanup",
        date: "2025-04-10",
        wasteCollected: "320kg",
        volunteers: 12
      },
      {
        id: 202,
        name: "Highway Cleanup",
        date: "2025-03-15",
        wasteCollected: "450kg",
        volunteers: 20
      },
      {
        id: 203,
        name: "School Campus",
        date: "2025-02-27",
        wasteCollected: "120kg",
        volunteers: 35
      }
    ];
    
    const mockBadges = [
      { id: 1, name: "First Cleanup", icon: "🌱", description: "Completed your first cleanup" },
      { id: 2, name: "Team Leader", icon: "👑", description: "Led a team of 10+ volunteers" },
      { id: 3, name: "Eco Warrior", icon: "🛡️", description: "Participated in 5+ cleanup drives" }
    ];

    // Simulate API call delay
    setTimeout(() => {
      setRequestsData(mockRequests);
      setUpcomingCamps(mockUpcomingCamps);
      setCompletedCamps(mockCompletedCamps);
      setBadges(mockBadges);
      setLoading(false);
    }, 800);
  }, []);

  // Handle camp participation response
  const handleCampResponse = (campId, response) => {
    setUpcomingCamps(upcomingCamps.map(camp => 
      camp.id === campId ? {...camp, status: response ? 'confirmed' : 'declined'} : camp
    ));
  };

  // Open create camp modal with selected request
  const handleCreateCamp = (request) => {
    setSelectedRequest(request);
    setShowCreateCampModal(true);
  };

  // Handle camp creation form submit
  const handleCampSubmit = (e) => {
    e.preventDefault();
    // Here you would submit the form data to your API
    
    // Mock success
    alert("Camp created successfully!");
    setShowCreateCampModal(false);
    setSelectedRequest(null);
  };

  return (
    <div className="flex min-h-screen bg-[#d1f1fa]">
      {/* Volunteer Navbar */}
      <VolunteerNavbar active="Home" />
      
      {/* Main Content */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold text-green-700 mb-2">Volunteer Dashboard</h1>
          <p className="text-gray-600 mb-6">
            Welcome back! View requests, manage camps, and track your impact.
          </p>

          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-xl p-4 shadow-md flex flex-col items-center">
              <div className="bg-green-50 p-3 rounded-full mb-2">
                <FaTrash className="text-2xl text-green-600" />
              </div>
              <h4 className="font-medium">Requests</h4>
              <p className="text-2xl font-bold">{requestsData.length}</p>
            </div>
            
            <div className="bg-white rounded-xl p-4 shadow-md flex flex-col items-center">
              <div className="bg-green-50 p-3 rounded-full mb-2">
                <FaCalendarAlt className="text-2xl text-green-600" />
              </div>
              <h4 className="font-medium">Upcoming Camps</h4>
              <p className="text-2xl font-bold">{upcomingCamps.length}</p>
            </div>
            
            <div className="bg-white rounded-xl p-4 shadow-md flex flex-col items-center">
              <div className="bg-green-50 p-3 rounded-full mb-2">
                <FaCheck className="text-2xl text-green-600" />
              </div>
              <h4 className="font-medium">Completed</h4>
              <p className="text-2xl font-bold">{completedCamps.length}</p>
            </div>
            
            <div className="bg-white rounded-xl p-4 shadow-md flex flex-col items-center">
              <div className="bg-green-50 p-3 rounded-full mb-2">
                <FaMedal className="text-2xl text-green-600" />
              </div>
              <h4 className="font-medium">Badges Earned</h4>
              <p className="text-2xl font-bold">{badges.length}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Waste Requests */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-green-700">
                  <FaMapMarkerAlt className="inline mr-2" />
                  Waste Removal Requests
                </h2>
              </div>
              
              {loading ? (
                <p className="text-center py-8 text-gray-500">Loading requests...</p>
              ) : requestsData.length > 0 ? (
                <div className="space-y-4 max-h-80 overflow-auto">
                  {requestsData.map(request => (
                    <div key={request.id} className="p-3 border border-gray-100 rounded-lg hover:bg-gray-50">
                      <div className="flex justify-between">
                        <div>
                          <h3 className="font-medium">{request.description}</h3>
                          <p className="text-sm text-gray-500">
                            <FaMapMarkerAlt className="inline mr-1" />
                            {request.location}
                          </p>
                          <p className="text-xs text-gray-400">Reported: {request.date}</p>
                        </div>
                        <Link
                          to={`/camp-register?requestId=${request.id}`}
                          className="bg-green-600 text-white text-sm px-3 py-1 rounded-full hover:bg-green-700"
                        >
                          Create Camp
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center py-8 text-gray-500">No pending requests found.</p>
              )}
            </div>
            
            {/* Upcoming Camps */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-green-700 mb-4">
                <FaCalendarAlt className="inline mr-2" />
                Upcoming Camps
              </h2>
              
              {loading ? (
                <p className="text-center py-8 text-gray-500">Loading camps...</p>
              ) : upcomingCamps.length > 0 ? (
                <div className="space-y-4 max-h-80 overflow-auto">
                  {upcomingCamps.map(camp => (
                    <div key={camp.id} className="p-3 border border-gray-100 rounded-lg hover:bg-gray-50">
                      <div className="flex justify-between">
                        <div>
                          <h3 className="font-medium">{camp.name}</h3>
                          <p className="text-sm text-gray-500">
                            <FaMapMarkerAlt className="inline mr-1" />
                            {camp.location}
                          </p>
                          <p className="text-xs text-gray-400">Date: {camp.date}</p>
                          <p className="text-xs text-gray-400">
                            <FaUsers className="inline mr-1" />
                            {camp.participants} participants
                          </p>
                        </div>
                        <div className="flex space-x-2">
                          {camp.status === 'pending' && (
                            <>
                              <button
                                onClick={() => handleCampResponse(camp.id, true)}
                                className="bg-green-600 text-white px-2 py-1 rounded hover:bg-green-700"
                                title="Join"
                              >
                                <FaCheck />
                              </button>
                              <button
                                onClick={() => handleCampResponse(camp.id, false)}
                                className="bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700"
                                title="Decline"
                              >
                                <FaTimes />
                              </button>
                            </>
                          )}
                          {camp.status === 'confirmed' && (
                            <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                              Joined
                            </span>
                          )}
                          {camp.status === 'declined' && (
                            <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded">
                              Declined
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center py-8 text-gray-500">No upcoming camps found.</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Badges Section */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-green-700 mb-4">
                <FaMedal className="inline mr-2" />
                Your Badges
              </h2>
              
              {loading ? (
                <p className="text-center py-8 text-gray-500">Loading badges...</p>
              ) : badges.length > 0 ? (
                <div className="flex flex-wrap gap-4">
                  {badges.map(badge => (
                    <div key={badge.id} className="flex flex-col items-center p-3 border border-gray-100 rounded-lg bg-green-50 w-24">
                      <div className="text-3xl mb-2">{badge.icon}</div>
                      <h3 className="font-medium text-sm text-center">{badge.name}</h3>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center py-8 text-gray-500">No badges earned yet. Start participating!</p>
              )}
            </div>
            
            {/* Completed Camps */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-green-700 mb-4">
                <FaCheck className="inline mr-2" />
                Completed Camps
              </h2>
              
              {loading ? (
                <p className="text-center py-8 text-gray-500">Loading history...</p>
              ) : completedCamps.length > 0 ? (
                <div className="space-y-4 max-h-80 overflow-auto">
                  {completedCamps.map(camp => (
                    <div key={camp.id} className="p-3 border border-gray-100 rounded-lg hover:bg-gray-50">
                      <h3 className="font-medium">{camp.name}</h3>
                      <div className="flex justify-between text-sm mt-1">
                        <p className="text-gray-500">Date: {camp.date}</p>
                        <p className="text-green-600 font-medium">{camp.wasteCollected} collected</p>
                      </div>
                      <p className="text-xs text-gray-400 mt-1">
                        <FaUsers className="inline mr-1" />
                        {camp.volunteers} volunteers participated
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center py-8 text-gray-500">No completed camps yet.</p>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Create Camp Modal */}
      {showCreateCampModal && selectedRequest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center p-4 z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-green-700 mb-4">Create Cleanup Camp</h2>
            <p className="text-gray-600 mb-4">
              Based on request at <strong>{selectedRequest.location}</strong>
            </p>
            
            <form onSubmit={handleCampSubmit}>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  Camp Name
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border rounded-lg"
                  placeholder="Enter a name for this camp"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  Date
                </label>
                <input
                  type="date"
                  className="w-full px-3 py-2 border rounded-lg"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  Time
                </label>
                <input
                  type="time"
                  className="w-full px-3 py-2 border rounded-lg"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  Maximum Volunteers
                </label>
                <input
                  type="number"
                  className="w-full px-3 py-2 border rounded-lg"
                  min="1"
                  max="100"
                  defaultValue="10"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  Description
                </label>
                <textarea
                  className="w-full px-3 py-2 border rounded-lg"
                  rows="3"
                  defaultValue={selectedRequest.description}
                  required
                ></textarea>
              </div>
              
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowCreateCampModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Create Camp
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default VolunteerDashboard;