import React, { useState, useEffect } from "react";
import { FaMapMarkerAlt, FaClipboardList, FaUpload, FaPlus } from "react-icons/fa";
import { MdDescription } from "react-icons/md";
import Navbar from "../components/Navbar";

const RequestPage = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    pincode: "",
    description: "",
    address: "",
    latitude: "",
    longitude: "",
    imageUrl: ""
  });
  const [imagePreview, setImagePreview] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");

  // Fetch user's previous requests on component mount
  useEffect(() => {
    // Mock data for demonstration - replace with actual API call
    setTimeout(() => {
      setRequests([
        {
          id: 1,
          date: "2025-05-10",
          location: "Park Street, Central Park",
          description: "Large pile of plastic waste",
          status: "Pending",
          imageUrl: "https://example.com/image1.jpg"
        },
        {
          id: 2,
          date: "2025-05-02",
          location: "River View Road, Downtown",
          description: "Illegal dumping near water body",
          status: "In Progress",
          imageUrl: "https://example.com/image2.jpg"
        },
        {
          id: 3,
          date: "2025-04-15",
          location: "Green Avenue, Westside",
          description: "Construction debris blocking sidewalk",
          status: "Completed",
          imageUrl: "https://example.com/image3.jpg"
        }
      ]);
      setLoading(false);
    }, 1000);

    // Auto-fetch user email if logged in
    setFormData(prev => ({
      ...prev,
      email: "user@example.com" // This would come from your auth context/state
    }));
  }, []);

  // Get location
  const getLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData({
            ...formData,
            latitude: position.coords.latitude.toString(),
            longitude: position.coords.longitude.toString(),
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          setError("Unable to fetch location. Please enter coordinates manually.");
        }
      );
    } else {
      setError("Geolocation is not supported by this browser.");
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // For demonstration - in a real app, you would upload this to a server
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result);
        setFormData({
          ...formData,
          imageUrl: reader.result // For implementation, this would be the URL from your server
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError("");
    
    try {
      // This would be your actual API call
      const response = await fetch("api/request_register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });
      
      if (!response.ok) {
        throw new Error("Failed to submit request");
      }
      
      // Handle successful submission
      alert("Request submitted successfully!");
      setShowForm(false);
      
      // Add the new request to the list (in real app, you'd refetch or update state properly)
      setRequests([
        {
          id: Date.now(),
          date: new Date().toISOString().split('T')[0],
          location: formData.address,
          description: formData.description,
          status: "Pending",
          imageUrl: formData.imageUrl
        },
        ...requests
      ]);
      
      // Reset form
      setFormData({
        email: formData.email, // Keep the email
        pincode: "",
        description: "",
        address: "",
        latitude: "",
        longitude: "",
        imageUrl: ""
      });
      setImagePreview(null);
      
    } catch (err) {
      setError(err.message || "Something went wrong");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-[#d1f1fa]">
      {/* Sidebar Navbar */}
      <Navbar active="Report" />
      
      {/* Main Content */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-green-700 mb-2">Waste Removal Requests</h1>
          <p className="text-gray-600 mb-6">
            Report illegal dumping or waste that needs to be removed from your community.
          </p>

          {/* New Request Button */}
          <div className="flex justify-end mb-6">
            <button
              onClick={() => setShowForm(!showForm)}
              className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-full flex items-center transition duration-300"
            >
              <FaPlus className="mr-2" />
              {showForm ? "Cancel Request" : "New Request"}
            </button>
          </div>

          {/* New Request Form */}
          {showForm && (
            <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
              <h2 className="text-xl font-bold text-green-700 mb-4">Submit New Request</h2>
              
              {error && (
                <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                  {error}
                </div>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
                      Email Address
                    </label>
                    <input
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      id="email"
                      name="email"
                      type="email"
                      placeholder="Your email address"
                      value={formData.email}
                      onChange={handleChange}
                      readOnly
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">Auto-fetched from your account</p>
                  </div>

                  <div>
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="pincode">
                      Pincode
                    </label>
                    <input
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      id="pincode"
                      name="pincode"
                      type="text"
                      placeholder="Enter pincode"
                      value={formData.pincode}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
                    Description of Waste
                  </label>
                  <div className="relative">
                    <div className="absolute left-3 top-3 text-green-600">
                      <MdDescription />
                    </div>
                    <textarea
                      className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      id="description"
                      name="description"
                      rows="3"
                      placeholder="Describe the type and amount of waste"
                      value={formData.description}
                      onChange={handleChange}
                      required
                    ></textarea>
                  </div>
                </div>

                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="address">
                    Address
                  </label>
                  <div className="relative">
                    <div className="absolute left-3 top-3 text-green-600">
                      <FaMapMarkerAlt />
                    </div>
                    <input
                      className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      id="address"
                      name="address"
                      type="text"
                      placeholder="Enter the full address"
                      value={formData.address}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <div className="flex justify-between">
                      <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="latitude">
                        Latitude
                      </label>
                      <button
                        type="button"
                        onClick={getLocation}
                        className="text-green-600 text-xs underline"
                      >
                        Auto Fetch Location
                      </button>
                    </div>
                    <input
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      id="latitude"
                      name="latitude"
                      type="text"
                      placeholder="Latitude"
                      value={formData.latitude}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="longitude">
                      Longitude
                    </label>
                    <input
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      id="longitude"
                      name="longitude"
                      type="text"
                      placeholder="Longitude"
                      value={formData.longitude}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="image">
                    Upload Image
                  </label>
                  <div className="flex items-center space-x-4">
                    <label className="flex items-center px-4 py-2 bg-green-100 text-green-700 rounded-lg cursor-pointer hover:bg-green-200 transition duration-300">
                      <FaUpload className="mr-2" />
                      <span>Choose File</span>
                      <input
                        id="image"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageChange}
                        required
                      />
                    </label>
                    {imagePreview && (
                      <div className="h-20 w-20 rounded-lg overflow-hidden">
                        <img
                          src={imagePreview}
                          alt="Preview"
                          className="h-full w-full object-cover"
                        />
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex justify-center pt-4">
                  <button
                    type="submit"
                    className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-full transition duration-300 flex items-center"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Submitting..." : "Submit Request"}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Previous Requests */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center mb-4">
              <FaClipboardList className="text-green-600 mr-2 text-xl" />
              <h2 className="text-xl font-bold text-green-700">Your Previous Requests</h2>
            </div>
            
            {loading ? (
              <p className="text-center py-8 text-gray-500">Loading your requests...</p>
            ) : requests.length > 0 ? (
              <div className="divide-y">
                {requests.map((request) => (
                  <div key={request.id} className="py-4 flex flex-col md:flex-row md:items-center">
                    <div className="md:w-1/4">
                      <div className="h-20 w-20 rounded-lg overflow-hidden bg-gray-200">
                        {/* This would be an actual image in a real app */}
                        <div className="h-full w-full flex items-center justify-center text-gray-400">
                          Image
                        </div>
                      </div>
                    </div>
                    <div className="md:w-2/4 mt-3 md:mt-0">
                      <h3 className="font-medium">{request.description}</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        <FaMapMarkerAlt className="inline mr-1" />
                        {request.location}
                      </p>
                      <p className="text-sm text-gray-500 mt-1">Reported on: {request.date}</p>
                    </div>
                    <div className="md:w-1/4 mt-3 md:mt-0 md:text-right">
                      <span 
                        className={`inline-block px-3 py-1 rounded-full text-xs font-medium
                          ${request.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' : 
                          request.status === 'In Progress' ? 'bg-blue-100 text-blue-800' : 
                          'bg-green-100 text-green-800'}`}
                      >
                        {request.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center py-8 text-gray-500">No requests found. Create your first request above!</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequestPage;