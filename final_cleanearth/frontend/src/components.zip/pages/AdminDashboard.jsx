import React, { useState, useEffect } from 'react';
import { FaUserShield, FaTrash, FaEye, FaLock, FaLockOpen } from 'react-icons/fa';
import { MdCleaningServices } from 'react-icons/md';

const AdminDashboard = () => {
  const [users, setUsers] = useState([
    { id: 1, name: 'John Doe', email: 'john@example.com', role: 'user', blocked: false },
    { id: 2, name: 'Sarah Smith', email: 'sarah@example.com', role: 'volunteer', blocked: true },
  ]);

  const [requests, setRequests] = useState([
    { id: 1, location: 'Central Park', description: 'Plastic waste accumulation', status: 'pending', pincode: '110001' },
    { id: 2, location: 'River Side', description: 'Illegal dumping', status: 'completed', pincode: '110002' },
  ]);

  const [camps, setCamps] = useState([
    { id: 1, name: 'Park Cleanup', date: '2023-03-15', volunteers: 15, location: 'Central Park', status: 'active' },
    { id: 2, name: 'River Cleanup', date: '2023-03-20', volunteers: 25, location: 'River Side', status: 'completed' },
  ]);

  const toggleUserBlock = (userId) => {
    setUsers(users.map(user => 
      user.id === userId ? { ...user, blocked: !user.blocked } : user
    ));
  };

  return (
    <div className="min-h-screen bg-[#d1f1fa]">
      {/* Admin Navbar */}
      <nav className="bg-green-600 text-white p-4 flex justify-between items-center shadow-lg">
        <div className="flex items-center">
          <MdCleaningServices className="text-2xl mr-2" />
          <span className="text-xl font-bold">CleanEarth Admin</span>
        </div>
        <div className="flex items-center space-x-4">
          <button className="hover:bg-green-700 px-3 py-1 rounded transition-colors">Dashboard</button>
          <button className="hover:bg-green-700 px-3 py-1 rounded transition-colors">Logout</button>
        </div>
      </nav>

      <div className="p-6 space-y-8">
        {/* User Management Section */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-2xl font-bold text-green-700 mb-4 flex items-center">
            <FaUserShield className="mr-2" />
            User Management
          </h2>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-green-50">
                <tr>
                  <th className="p-3 text-left text-green-700">Name</th>
                  <th className="p-3 text-left text-green-700">Email</th>
                  <th className="p-3 text-left text-green-700">Role</th>
                  <th className="p-3 text-left text-green-700">Status</th>
                  <th className="p-3 text-left text-green-700">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.id} className="border-t hover:bg-gray-50">
                    <td className="p-3">{user.name}</td>
                    <td className="p-3">{user.email}</td>
                    <td className="p-3 capitalize">{user.role}</td>
                    <td className="p-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${user.blocked ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-700'}`}>
                        {user.blocked ? 'Blocked' : 'Active'}
                      </span>
                    </td>
                    <td className="p-3">
                      <button 
                        onClick={() => toggleUserBlock(user.id)}
                        className="p-2 rounded hover:bg-green-50"
                      >
                        {user.blocked ? (
                          <FaLockOpen className="text-green-600" />
                        ) : (
                          <FaLock className="text-red-600" />
                        )}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Requests Section */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-2xl font-bold text-green-700 mb-4 flex items-center">
            <FaEye className="mr-2" />
            All Requests
          </h2>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-green-50">
                <tr>
                  <th className="p-3 text-left text-green-700">Location</th>
                  <th className="p-3 text-left text-green-700">Description</th>
                  <th className="p-3 text-left text-green-700">Status</th>
                  <th className="p-3 text-left text-green-700">Pincode</th>
                  <th className="p-3 text-left text-green-700">Actions</th>
                </tr>
              </thead>
              <tbody>
                {requests.map(request => (
                  <tr key={request.id} className="border-t hover:bg-gray-50">
                    <td className="p-3">{request.location}</td>
                    <td className="p-3">{request.description}</td>
                    <td className="p-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        request.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-700'
                      }`}>
                        {request.status}
                      </span>
                    </td>
                    <td className="p-3">{request.pincode}</td>
                    <td className="p-3">
                      <button className="p-2 rounded hover:bg-green-50">
                        <FaTrash className="text-red-600" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Camps Section */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-2xl font-bold text-green-700 mb-4 flex items-center">
            <MdCleaningServices className="mr-2" />
            Camp Details
          </h2>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-green-50">
                <tr>
                  <th className="p-3 text-left text-green-700">Camp Name</th>
                  <th className="p-3 text-left text-green-700">Date</th>
                  <th className="p-3 text-left text-green-700">Volunteers</th>
                  <th className="p-3 text-left text-green-700">Location</th>
                  <th className="p-3 text-left text-green-700">Status</th>
                </tr>
              </thead>
              <tbody>
                {camps.map(camp => (
                  <tr key={camp.id} className="border-t hover:bg-gray-50">
                    <td className="p-3">{camp.name}</td>
                    <td className="p-3">{camp.date}</td>
                    <td className="p-3">{camp.volunteers}</td>
                    <td className="p-3">{camp.location}</td>
                    <td className="p-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        camp.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                      }`}>
                        {camp.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;