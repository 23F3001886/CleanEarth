import React, { useState, useEffect, useId } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { FaCalendarAlt, FaUsers, FaClock, FaMapMarkerAlt } from "react-icons/fa";
import { MdDescription } from "react-icons/md";
import VolunteerNavbar from "../components/VolunteerNavbar";

const CampRegister = () => {
  // Get request ID from URL parameters
  const [searchParams] = useSearchParams();
  const requestId = searchParams.get("requestId");
  const navigate = useNavigate();
  
  // Generate unique camp ID using useId hook
  const uniqueCampId = useId();
  
  // Form data
  const [formData, setFormData] = useState({
    campId: "",
    requestId: requestId || "",
    campName: "",
    dateOfCamp: "",
    timeOfCamp: "",
    numberOfVolunteers: 10,
    description: "",
    location: "",
    volunteerEmail: "",
    requestDetails: {}
  });
  
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch request details and volunteer email on component mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        
        // In a real app, you would fetch the request details from your API
        // Mock API call to fetch request details
        const requestData = {
          id: requestId,
          location: "Green Park, Sector 15",
          description: "Large plastic waste accumulation near the park entrance",
          pincode: "110049",
          latitude: "28.5621",
          longitude: "77.2841",
          imageUrl: "https://example.com/waste-image.jpg"
        };
        
        // Auto-fetch volunteer email (in real app, get from auth context)
        const volunteerEmail = "volunteer@cleanearth.org";
        
        // Update form data with fetched information
        setFormData({
          ...formData,
          campId: `CAMP-${uniqueCampId.replace(/:/g, "")}-${Date.now().toString().slice(-6)}`,
          requestId: requestId,
          description: requestData.description,
          location: requestData.location,
          volunteerEmail: volunteerEmail,
          requestDetails: requestData
        });
        
        setIsLoading(false);
      } catch (err) {
        setError("Failed to load request details. Please try again.");
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [requestId, uniqueCampId, formData]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError("");
    
    try {
      // Validate form data
      if (!formData.campName || !formData.dateOfCamp || !formData.timeOfCamp) {
        throw new Error("Please fill all required fields");
      }
      
      // In a real app, you would send the data to your API
      console.log("Submitting camp data:", formData);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Show success message or redirect
      alert("Camp successfully created!");
      // In a real app, you would redirect to camps page
      navigate('/camps');
      
    } catch (err) {
      setError(err.message || "Failed to create camp. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-[#d1f1fa]">
      {/* Volunteer Navbar */}
      <VolunteerNavbar active="Camps" />
      
      {/* Main Content */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold text-green-700 mb-2">Create Cleanup Camp</h1>
          <p className="text-gray-600 mb-6">
            Organize a cleanup drive based on the waste report. Set details and invite volunteers.
          </p>
          
          {isLoading ? (
            <div className="bg-white rounded-xl shadow-lg p-8 flex justify-center items-center h-64">
              <p className="text-gray-500">Loading request details...</p>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-lg p-8">
              {error && (
                <div className="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                  {error}
                </div>
              )}
              
              <div className="mb-6 bg-green-50 rounded-lg p-4">
                <h3 className="font-medium text-green-800">Request Details</h3>
                <p className="text-sm mt-2">{formData.requestDetails.description}</p>
                <p className="text-sm text-gray-500 mt-1">
                  <FaMapMarkerAlt className="inline mr-1" />
                  {formData.requestDetails.location}
                </p>
              </div>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="campId">
                    Camp ID
                  </label>
                  <input
                    className="w-full px-4 py-3 bg-gray-100 border border-gray-200 rounded-lg text-gray-500"
                    id="campId"
                    name="campId"
                    type="text"
                    value={formData.campId}
                    readOnly
                  />
                  <p className="text-xs text-gray-500 mt-1">Auto-generated unique identifier</p>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="campName">
                    Camp Name
                  </label>
                  <div className="relative">
                    <div className="absolute left-3 top-3 text-green-600">
                      <FaCalendarAlt />
                    </div>
                    <input
                      className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      id="campName"
                      name="campName"
                      type="text"
                      placeholder="Give your cleanup camp a name"
                      value={formData.campName}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="dateOfCamp">
                      Date of Camp
                    </label>
                    <div className="relative">
                      <div className="absolute left-3 top-3 text-green-600">
                        <FaCalendarAlt />
                      </div>
                      <input
                        className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                        id="dateOfCamp"
                        name="dateOfCamp"
                        type="date"
                        value={formData.dateOfCamp}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="timeOfCamp">
                      Time of Camp
                    </label>
                    <div className="relative">
                      <div className="absolute left-3 top-3 text-green-600">
                        <FaClock />
                      </div>
                      <input
                        className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                        id="timeOfCamp"
                        name="timeOfCamp"
                        type="time"
                        value={formData.timeOfCamp}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="numberOfVolunteers">
                    Number of Volunteers Needed
                  </label>
                  <div className="relative">
                    <div className="absolute left-3 top-3 text-green-600">
                      <FaUsers />
                    </div>
                    <input
                      className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      id="numberOfVolunteers"
                      name="numberOfVolunteers"
                      type="number"
                      min="1"
                      max="100"
                      value={formData.numberOfVolunteers}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
                    Camp Description
                  </label>
                  <div className="relative">
                    <div className="absolute left-3 top-3 text-green-600">
                      <MdDescription />
                    </div>
                    <textarea
                      className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                      id="description"
                      name="description"
                      rows="3"
                      placeholder="Describe the cleanup camp activities and requirements"
                      value={formData.description}
                      onChange={handleChange}
                      required
                    ></textarea>
                  </div>
                </div>

                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="volunteerEmail">
                    Organizer Email
                  </label>
                  <input
                    className="w-full px-4 py-3 bg-gray-100 border border-gray-200 rounded-lg text-gray-500"
                    id="volunteerEmail"
                    name="volunteerEmail"
                    type="email"
                    value={formData.volunteerEmail}
                    readOnly
                  />
                  <p className="text-xs text-gray-500 mt-1">Auto-fetched from your account</p>
                </div>
                
                <div className="flex justify-center pt-4">
                  <button
                    type="submit"
                    className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-full transition duration-300 flex items-center"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Creating Camp..." : "Create Cleanup Camp"}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CampRegister;